<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Live Search + Export</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h2>Filter Data Berdasarkan Tanggal</h2>
    
    <label>Dari Tanggal:</label>
    <input type="date" id="tanggal_awal">
    <label>Sampai Tanggal:</label>
    <input type="date" id="tanggal_akhir">
    <button id="filter">Tampilkan</button>

    <form method="POST" action="export_excel.php" id="exportForm">
        <input type="hidden" name="tanggal_awal" id="export_tanggal_awal">
        <input type="hidden" name="tanggal_akhir" id="export_tanggal_akhir">
        <button type="submit">Cetak ke Excel</button>
    </form>

    <div id="hasil">
        <!-- Data hasil pencarian muncul di sini -->
    </div>

    <script>
        function loadData() {
            let awal = $('#tanggal_awal').val();
            let akhir = $('#tanggal_akhir').val();

            // Update hidden form
            $('#export_tanggal_awal').val(awal);
            $('#export_tanggal_akhir').val(akhir);

            $.ajax({
                url: 'fetch_data.php',
                method: 'POST',
                data: { tanggal_awal: awal, tanggal_akhir: akhir },
                success: function(response) {
                    $('#hasil').html(response);
                }
            });
        }

        $('#filter').click(function() {
            loadData();
        });

        // Load data awal (semua)
        $(document).ready(function() {
            loadData();
        });
    </script>
</body>
</html>
