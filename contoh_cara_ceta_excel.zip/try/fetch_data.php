<?php
include 'koneksi.php';

$tanggal_awal = $_POST['tanggal_awal'] ?? '';
$tanggal_akhir = $_POST['tanggal_akhir'] ?? '';

$query = "SELECT * FROM data";

if (!empty($tanggal_awal) && !empty($tanggal_akhir)) {
    $query .= " WHERE tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'";
}

$result = mysqli_query($conn, $query);

echo "<table border='1'>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Tanggal</th>
        </tr>";
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td><?php echo $no++; ?></td>
            <td>{$row['nama']}</td>
            <td>{$row['tanggal']}</td>
          </tr>";
}
echo "</table>";
?>
