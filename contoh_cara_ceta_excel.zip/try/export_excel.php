<?php
include 'koneksi.php';

$tanggal_awal = $_POST['tanggal_awal'];
$tanggal_akhir = $_POST['tanggal_akhir'];

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="laporan.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Laporan Bulanan'], ';');
fputcsv($output, ['No', 'Nama', 'Tanggal'], ';');

$query = "SELECT * FROM data WHERE tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'";
$result = mysqli_query($conn, $query);

$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, [$no++, $row['nama'], $row['tanggal']], ';');
}

fclose($output);
exit;
?>
