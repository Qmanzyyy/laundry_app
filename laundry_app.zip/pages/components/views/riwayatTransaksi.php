<?php
$query = "
    SELECT 
        t.id, t.tgl,m.nama, j.jenis_cuci, p.jumlah, p.harga, t.deleted_at
    FROM tb_transaksi t
    JOIN tb_paket p ON t.id = p.id
    JOIN tb_jenis_cuci j ON t.id_jenis_cuci = j.id
    JOIN tb_member m ON t.id_member = m.id
    WHERE t.deleted_at IS NULL
";

$result = mysqli_query($conn, $query);

$dataTransaksi = [];
while ($row = mysqli_fetch_assoc($result)) {
    $dataTransaksi[] = $row;
}
?>

<main class="min-h-dvh overflow-x-auto py-6 px-6">
    <div class="mx-auto  shadow-lg rounded-md p-4 sm:p-6 max-w-screen">
        <h1 class="text-2xl font-bold text-center mb-6 text-blue-600">Riwayat Transaksi</h1>
        
        <!-- Filter Tanggal -->
        <div class="flex flex-wrap sm:flex-nowrap items-end justify-center gap-4 sm:gap-6 p-4 sm:p-6 mb-6">
            <div class="flex flex-col w-full sm:w-auto">
                <label for="date" class="text-sm text-gray-600 font-medium mb-2">Cetak dari tanggal</label>
                <input type="date" name="date" id="date"
                    class="w-full sm:w-56 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition">
            </div>

            <div class="hidden sm:flex items-center text-gray-400 text-xl font-semibold">→</div>

            <div class="flex flex-col w-full sm:w-auto">
                <label for="sdate" class="text-sm text-gray-600 font-medium mb-2">Sampai tanggal</label>
                <input type="date" name="date" id="sdate"
                    class="w-full sm:w-56 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 transition">
            </div>

            <button
                class="self-end inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-lg shadow transition">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M6 9V2h12v7M6 18h12v4H6v-4zM6 14h12v2H6v-2zM6 10h12v2H6v-2z" />
                </svg>
                Cetak
            </button>
        </div>

        <!-- Tabel Transaksi -->
        <div class="overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 hidden md:block">
            <table class="min-w-full bg-white border border-gray-200 rounded-lg shadow text-sm">
                <thead class="bg-gray-500 text-white">
                    <tr>
                        <th class="px-4 py-2 text-left font-semibold  whitespace-nowrap">No</th>
                        <th class="px-4 py-2 text-left font-semibold  whitespace-nowrap">Tanggal & Waktu</th>
                        <th class="px-4 py-2 text-left font-semibold  whitespace-nowrap">Pemesan</th>
                        <th class="px-4 py-2 text-left font-semibold  whitespace-nowrap">Jenis Cuci</th>
                        <th class="px-4 py-2 text-left font-semibold  whitespace-nowrap">Jumlah(kg)</th>
                        <th class="px-4 py-2 text-left font-semibold  whitespace-nowrap">Total Harga</th>
                        <?php if ($_SESSION['user_role'] != 'kasir'):?>
                        <th class="px-4 py-2 text-left font-semibold  whitespace-nowrap">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($dataTransaksi as $row): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-2 whitespace-nowrap"><?= $no++ ?></td>
                            <td class="px-4 py-2 whitespace-nowrap"><?= $row['tgl'] ?></td>
                            <td class="px-4 py-2 whitespace-nowrap"><?= $row['nama'] ?></td>
                            <td class="px-4 py-2 whitespace-nowrap"><?= $row['jenis_cuci'] ?></td>
                            <td class="px-4 py-2 whitespace-nowrap"><?= $row['jumlah'] ?></td>
                            <td class="px-4 py-2 whitespace-nowrap">Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
                            <?php if ($_SESSION['user_role'] != 'kasir'):?>
                            <td class="px-4 py-2 whitespace-nowrap">
                                <a href="#"
                                   onclick="softDelete(<?= $row['id'] ?>)"
                                   class="inline-flex items-center px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600 transition">
                                    <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24">
                                        <path fill-rule="evenodd"
                                              d="M8.586 2.586A2 2 0 0 1 10 2h4a2 2 0 0 1 2 2v2h3a1 1 0 1 1 0 
                                              2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V8a1 1 0 0 1 0-2h3V4a2 
                                              2 0 0 1 .586-1.414ZM10 6h4V4h-4v2Zm1 4a1 1 0 1 
                                              0-2 0v8a1 1 0 1 0 2 0v-8Zm4 0a1 1 0 1 
                                              0-2 0v8a1 1 0 1 0 2 0v-8Z"
                                              clip-rule="evenodd"/>
                                    </svg>
                                    Hapus
                                </a>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <!-- Tabel Transaksi mobile -->
        <div class="overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 md:hidden block">
            <p>ini mobile</p>
        </div>
    </div>
</main>
